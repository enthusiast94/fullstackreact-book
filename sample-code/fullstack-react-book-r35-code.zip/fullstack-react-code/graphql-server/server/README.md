## Running the app

```
npm start
```