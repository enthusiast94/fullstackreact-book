## Counter

```jsx
<CounterWrapper />
```


The `CounterWrapper` supplies an initial value to `Counter`. `Counter` displays a "+" and a "-" button to change the count.
