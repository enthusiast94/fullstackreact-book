## Switch

    <Switch />

Switch between choices.
