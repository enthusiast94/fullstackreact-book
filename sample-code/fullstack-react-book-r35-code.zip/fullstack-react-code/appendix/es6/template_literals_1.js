
var greeting = 'Hello, ' + user + '! It is ' + degF + ' degrees outside.';
